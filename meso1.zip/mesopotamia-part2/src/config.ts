export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

/**
 * Geser sinkron (detik). Positif = subtitle dan animasi muncul LEBIH LAMBAT dari suara,
 * negatif = lebih cepat. Audio tetap diputar dari detik 0.
 */
export const AUDIO_OFFSET = 0;

/** Lama transisi antar beat (frame). */
export const TRANSITION_FRAMES = 14;

export type Box = {x: number; y: number; w: number; h: number};

/** Koordinat kanvas (piksel), semuanya eksplisit. Tidak ada kotak yang saling tumpang tindih. */
export const LAYOUT = {
  title: {x: 60, y: 60, w: 960, h: 170},
  label: {x: 60, y: 250, w: 600, h: 80},
  arena: {x: 0, y: 350, w: 1080, h: 1050},
  decor: {x: 0, y: 1410, w: 1080, h: 36},
  subtitle: {x: 60, y: 1460, w: 960, h: 280},
} as const;

/** Koordinat di dalam arena (relatif terhadap pojok kiri-atas arena). */
export const HERO: Box = {x: 40, y: 350, w: 400, h: 660};
export const OBJ: Box = {x: 480, y: 70, w: 560, h: 920};

export const COLORS = {
  night: '#2B1A0E',
  ink: '#2A1608',
  clay: '#C98B4B',
  mud: '#D9A760',
  mudLight: '#EBC98A',
  mudDark: '#A8713A',
  shadow: '#7A4A24',
  cape: '#8C1F18',
  capeDark: '#5E1410',
  gold: '#E0A82E',
  tunic: '#D9B98C',
  wood: '#8A5A2B',
  river: '#3E8FA6',
  riverLight: '#CFE9F0',
  palm: '#4F7A34',
  highlight: '#FFD21F',
  paper: '#F4E8CF',
  nightSky: '#0B2433',
} as const;

export const FONT = '"Arial Black", "Impact", Arial, sans-serif';

/**
 * Data timestamp dari SRT (detik). Semua tampilan subtitle, sorotan kata, dan
 * durasi tiap beat dihitung dari data ini (lihat src/lib/timing.ts).
 */
export type Cue = {start: number; end: number; text: string};

export const CUES: Cue[] = [
  {start: 0.1, end: 4.48, text: 'Seiring berkembangnya Mesopotamia, berbagai penemuan mulai mengubah kehidupan'},
  {start: 4.48, end: 5.06, text: 'manusia.'},
  {start: 5.74, end: 10.42, text: 'Bangsa Sumeria mengembangkan tulisan cuneiform untuk mencatat perdagangan dan'},
  {start: 10.42, end: 14.86, text: 'peristiwa. Mereka juga menggunakan roda untuk mempermudah transportasi.'},
  {start: 15.58, end: 20.64, text: 'Dalam matematika, mereka mengembangkan sistem bilangan berbasis 60 yang masih'},
  {start: 20.64, end: 25.42, text: 'kita gunakan dalam pembagian waktu hingga sekarang. Mereka mempelajari bintang dan'},
  {start: 25.42, end: 30.24, text: 'planet, mengembangkan kalender, serta membangun sistem irigasi untuk pertanian.'},
  {start: 30.84, end: 35.44, text: 'Tak hanya itu, mereka juga membangun zigurat, bangunan bertingkat megah sebagai'},
  {start: 35.44, end: 39.6, text: 'pusat keagamaan. Penemuan dan perkembangan ini menjadi salah satu'},
  {start: 39.6, end: 42.34, text: 'fondasi penting bagi kemajuan peradaban manusia.'},
];

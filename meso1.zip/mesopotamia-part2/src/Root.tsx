import React from 'react';
import {Composition} from 'remotion';
import {FPS, HEIGHT, WIDTH} from './config';
import {Mesopotamia} from './Mesopotamia';
import {TOTAL_FRAMES} from './lib/timing';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Mesopotamia"
      component={Mesopotamia}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};

import {AUDIO_OFFSET, FPS} from '../config';
import {CUES} from '../data/captions';

export type Word = {
  text: string;
  start: number; // detik (sudah termasuk AUDIO_OFFSET)
  end: number;
  startFrame: number;
  endFrame: number;
};

const letters = (s: string) => Math.max(1, (s.match(/[\p{L}\p{N}]/gu) ?? []).length);

/** Waktu tiap kata: durasi cue dibagi proporsional jumlah huruf. */
export const WORDS: Word[] = CUES.flatMap((cue) => {
  const ws = cue.text.split(/\s+/).filter(Boolean);
  const total = ws.reduce((a, w) => a + letters(w), 0);
  const dur = cue.end - cue.start;
  let cum = 0;
  return ws.map((text) => {
    const s = cue.start + (dur * cum) / total + AUDIO_OFFSET;
    cum += letters(text);
    const e = cue.start + (dur * cum) / total + AUDIO_OFFSET;
    return {
      text,
      start: s,
      end: e,
      startFrame: Math.round(s * FPS),
      endFrame: Math.round(e * FPS),
    };
  });
});

/** Durasi total = akhir kata terakhir + 1 detik. */
export const TOTAL_FRAMES = Math.round((WORDS[WORDS.length - 1].end + 1) * FPS);

/**
 * Tiap beat dimulai di kata ke-N (indeks kata, dihitung dari 0).
 * Jika narasi/SRT diganti, sesuaikan angka startWord di sini.
 */
export const BEAT_DEFS = [
  {startWord: 0, title: 'Mesopotamia yang Maju', label: 'Sumeria, ±3500 SM'},
  {startWord: 9, title: 'Tulisan Cuneiform', label: 'Uruk, ±3200 SM'},
  {startWord: 19, title: 'Roda', label: 'Roda, ±3500 SM'},
  {startWord: 26, title: 'Matematika Berbasis 60', label: 'Sistem Bilangan 60'},
  {startWord: 43, title: 'Astronomi', label: 'Kalender Bintang'},
  {startWord: 50, title: 'Irigasi & Pertanian', label: 'Sistem Irigasi'},
  {startWord: 56, title: 'Ziggurat', label: 'Ziggurat Ur'},
  {startWord: 69, title: 'Warisan Besar', label: 'Fondasi Peradaban'},
] as const;

export type BeatTiming = {start: number; end: number};

export const BEATS: BeatTiming[] = BEAT_DEFS.map((def, i) => {
  const start = i === 0 ? 0 : WORDS[def.startWord].startFrame;
  const next = BEAT_DEFS[i + 1];
  const end = next ? WORDS[next.startWord].startFrame : TOTAL_FRAMES;
  return {start, end};
});

import {TOTAL_FRAMES, WORDS} from './timing';

export type Page = {
  lines: number[][]; // indeks kata per baris
  startFrame: number;
  endFrame: number;
};

const MAX_CHARS = 19;
const MAX_LINES = 3;

const packLines = (idx: number[]): number[][] => {
  const lines: number[][] = [[]];
  let len = 0;
  for (const i of idx) {
    const w = WORDS[i].text.length;
    const cur = lines[lines.length - 1];
    const add = cur.length ? w + 1 : w;
    if (cur.length && len + add > MAX_CHARS) {
      lines.push([i]);
      len = w;
    } else {
      cur.push(i);
      len += add;
    }
  }
  return lines;
};

const groups: number[][] = [];
let current: number[] = [];
WORDS.forEach((w, i) => {
  if (current.length && packLines([...current, i]).length > MAX_LINES) {
    groups.push(current);
    current = [];
  }
  current.push(i);
  if (/[.!?]$/.test(w.text)) {
    groups.push(current);
    current = [];
  }
});
if (current.length) groups.push(current);

export const PAGES: Page[] = groups.map((g, k) => ({
  lines: packLines(g),
  startFrame: WORDS[g[0]].startFrame,
  endFrame: k + 1 < groups.length ? WORDS[groups[k + 1][0]].startFrame : TOTAL_FRAMES,
}));

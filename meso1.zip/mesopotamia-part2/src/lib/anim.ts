import {Easing, interpolate} from 'remotion';

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
export const easeOut = Easing.bezier(0.22, 1, 0.36, 1);
export const easeIO = Easing.bezier(0.65, 0, 0.35, 1);
export const linear = (t: number) => t;

/** Nilai dari a ke b antara frame `from` dan `from + dur`, tertahan di ujung-ujungnya. */
export const tween = (
  f: number,
  from: number,
  dur: number,
  a: number,
  b: number,
  easing: (t: number) => number = easeOut,
) =>
  interpolate(f, [from, from + Math.max(1, dur)], [a, b], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing,
  });

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

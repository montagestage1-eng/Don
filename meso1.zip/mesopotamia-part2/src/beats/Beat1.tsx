import React from 'react';
import {BEAT_DEFS} from '../lib/timing';
import {BeatShell} from '../components/Ui';
import {Boat, Cloud, Ground, Hills, House, Palm, River, Sky, Ziggurat} from '../components/Scenery';
import {Stickman} from '../components/Stickman';
import {easeIO, lerp, tween} from '../lib/anim';
import {BeatProps} from './types';

const HZ = 520;
const VPX = 760;

/** Beat 1: kota Mesopotamia, kamera maju pelan menyusuri sungai. Fokus: ziggurat di kejauhan. */
export const Beat1: React.FC<BeatProps> = ({f, at}) => {
  const def = BEAT_DEFS[0];
  const dolly = tween(f, 0, 170, 1, 1.12, easeIO);
  const heroX = tween(f, 0, 42, -340, 40);
  const walking = f < 42;
  const swing = Math.sin(f * 0.5);
  const point = tween(f, 42, 14, 0, 1);
  const front = walking ? {a: -26 * swing, b: 10} : {a: lerp(20, 100, point), b: lerp(10, 6, point)};
  const back = walking ? {a: 26 * swing, b: 10} : {a: 8, b: 8};
  const u = tween(f, 0, 190, 0.2, 0.8, (t) => t);
  const boatY = lerp(HZ, 1050, Math.pow(u, 1.8));
  const boatX = lerp(VPX, 910, Math.pow(u, 1.8));
  return (
    <BeatShell f={f} title={def.title} label={def.label} labelAt={at(2)}>
      <Sky id="sky1" h={HZ} stops={['#7EC0D4', '#F7E3B5']} />
      <Cloud x={200 + f * 0.3} y={110} s={1.2} />
      <Cloud x={820 - f * 0.2} y={200} s={0.8} />
      <g transform={`translate(${VPX} ${HZ}) scale(${dolly}) translate(${-VPX} ${-HZ})`}>
        <Hills hz={HZ} amp={70} color="#D8B98A" seed={1} />
        <Ziggurat cx={760} baseY={HZ - 6} w={400} levels={5} tierH={50} p={5} />
        <Ground hz={HZ} bottom={1050} vpx={VPX} color="#E2B777" line={'#A8713A'} />
        <River vpx={VPX} hz={HZ} bottom={1050} xl={520} xr={1300} f={f} />
        <House x={520} y={560} w={56} h={56} d={20} />
        <House x={400} y={585} w={70} h={70} d={26} />
        <House x={250} y={620} w={92} h={88} d={34} />
        <House x={80} y={680} w={120} h={120} d={46} />
        <House x={845} y={560} w={60} h={58} d={20} side="left" />
        <House x={930} y={600} w={90} h={88} d={30} side="left" />
        <House x={1010} y={690} w={130} h={130} d={44} side="left" />
        <Palm x={620} y={565} s={0.5} sway={Math.sin(f * 0.07) * 4} />
        <Palm x={1040} y={650} s={0.8} sway={Math.sin(f * 0.06 + 1) * 5} />
        <Boat x={boatX} y={boatY} s={0.3 + 0.9 * u} />
      </g>
      <ellipse cx={heroX + 200} cy={1008} rx={130} ry={16} fill={'#7A4A24'} opacity={0.3} />
      <Stickman
        x={heroX}
        y={350}
        front={front}
        back={back}
        walk={walking ? f * 0.5 : undefined}
        face={walking ? 'normal' : 'happy'}
        blink={f % 96 < 4}
        sway={Math.sin(f * 0.15) * 10}
        bob={walking ? Math.abs(swing) * -6 : Math.sin(f * 0.12) * 3}
      />
    </BeatShell>
  );
};

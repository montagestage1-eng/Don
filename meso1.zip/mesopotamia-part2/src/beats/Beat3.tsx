import React from 'react';
import {COLORS} from '../config';
import {BEAT_DEFS} from '../lib/timing';
import {BeatShell} from '../components/Ui';
import {Cloud, Ground, Hills, House, Sky, Wheel} from '../components/Scenery';
import {Stickman} from '../components/Stickman';
import {tween} from '../lib/anim';
import {BeatProps} from './types';

const HZ = 480;

/** Beat 3: gerobak dan roda besar masuk cepat dari kanan; roda berputar, tanah bergulir. */
export const Beat3: React.FC<BeatProps> = ({f, at}) => {
  const def = BEAT_DEFS[2];
  const enter = tween(f, 0, 22, 560, 0);
  const rot = f * 6;
  const spoke = at(22); // "roda"
  const pulse = tween(f, spoke, 10, 0, 1) * (1 - tween(f, spoke + 10, 14, 0, 1));
  const marks = Array.from({length: 8}, (_, k) => {
    const x = (((k * 150 - f * 9) % 1200) + 1200) % 1200 - 60;
    return <path key={k} d={`M${x} 960 H${x + 70}`} stroke={COLORS.shadow} strokeWidth={6} strokeLinecap="round" opacity={0.6} />;
  });
  return (
    <BeatShell f={f} title={def.title} label={def.label} labelAt={at(22)}>
      <Sky id="sky3" h={HZ} stops={['#7EC0D4', '#F7E3B5']} />
      <Cloud x={300 + f * 0.4} y={120} />
      <Hills hz={HZ} amp={50} color="#D8B98A" seed={3} />
      <House x={150} y={HZ + 8} w={64} h={60} d={22} />
      <House x={330} y={HZ + 6} w={50} h={46} d={18} />
      <House x={640} y={HZ + 8} w={70} h={64} d={24} />
      <Ground hz={HZ} bottom={1050} vpx={540} color="#E2B777" line="#A8713A" />
      <path d={`M0 ${1010} H1080`} stroke={COLORS.shadow} strokeWidth={4} opacity={0.4} />
      {marks}
      <g transform={`translate(${enter} 0)`}>
        {/* gerobak */}
        <g stroke={COLORS.ink} strokeWidth={5} strokeLinejoin="round">
          <rect x={780} y={560} width={250} height={150} fill="#B9803F" />
          {[820, 870, 920, 970].map((x) => (
            <path key={x} d={`M${x} 560 V710`} />
          ))}
          <path d="M780 560 L810 530 H1040 L1030 560" fill="#D2A05B" />
          <ellipse cx={900} cy={528} rx={46} ry={16} fill="#E9D9A8" />
        </g>
        <Wheel cx={930} cy={770} r={88} rot={rot * 1.4} />
        {/* roda besar sebagai fokus */}
        <g transform={`translate(690 700) scale(${1 + pulse * 0.06}) translate(-690 -700)`}>
          <Wheel cx={690} cy={700} r={190} rot={rot} />
        </g>
      </g>
      <ellipse cx={240} cy={1008} rx={130} ry={16} fill={COLORS.shadow} opacity={0.35} />
      <Stickman
        x={40}
        y={350}
        front={{a: 98, b: 2}}
        back={{a: 92, b: 4}}
        walk={f * 0.4}
        lean={8}
        face="happy"
        blink={f % 96 < 4}
        sway={14 + Math.sin(f * 0.3) * 6}
        bob={Math.abs(Math.sin(f * 0.4)) * -5}
      />
    </BeatShell>
  );
};

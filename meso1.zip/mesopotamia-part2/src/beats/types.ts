/** f = frame lokal beat (0 = awal narasi beat ini), at(w) = frame lokal saat kata ke-w mulai diucapkan. */
export type BeatProps = {
  f: number;
  at: (wordIndex: number) => number;
};

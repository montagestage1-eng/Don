import React from 'react';
import {COLORS} from '../config';
import {BEAT_DEFS} from '../lib/timing';
import {BeatShell} from '../components/Ui';
import {BrickWall, Glyph, Tablet} from '../components/Scenery';
import {Stickman} from '../components/Stickman';
import {tween} from '../lib/anim';
import {BeatProps} from './types';

/** Beat 2: tablet tanah liat diukir, simbol muncul satu per satu mengikuti kata "cuneiform". */
export const Beat2: React.FC<BeatProps> = ({f, at}) => {
  const def = BEAT_DEFS[1];
  const rise = tween(f, 0, 20, 700, 0);
  const start = at(13); // "cuneiform"
  const carving = f >= start && f < start + 24 * 3 + 10;
  const tap = carving ? Math.sin(f * 0.6) * 5 : 0;
  return (
    <BeatShell f={f} title={def.title} label={def.label} labelAt={at(13)}>
      <BrickWall h={1050} />
      <rect x={0} y={970} width={1080} height={80} fill={COLORS.wood} />
      <path d="M0 970 H1080" stroke={COLORS.ink} strokeWidth={5} />
      <g transform={`translate(0 ${rise})`}>
        <Tablet x={500} y={170} w={520} h={700}>
          {Array.from({length: 24}, (_, i) => {
            const col = i % 4;
            const row = Math.floor(i / 4);
            const s = tween(f, start + i * 3, 10, 0, 1.1);
            return <Glyph key={i} x={540 + col * 118} y={240 + row * 106} s={s} k={i * 3 + row} />;
          })}
        </Tablet>
      </g>
      <ellipse cx={240} cy={1008} rx={130} ry={16} fill={COLORS.shadow} opacity={0.35} />
      <Stickman
        x={40}
        y={350}
        front={{a: 100 + tap, b: 8}}
        back={{a: 6, b: 8}}
        tool={{kind: 'pointer', angle: 100 + tap}}
        face={carving ? 'happy' : 'normal'}
        blink={f % 96 < 4}
        sway={Math.sin(f * 0.15) * 8}
        bob={Math.sin(f * 0.12) * 3}
      />
    </BeatShell>
  );
};

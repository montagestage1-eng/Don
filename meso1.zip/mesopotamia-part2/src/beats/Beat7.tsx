import React from 'react';
import {COLORS} from '../config';
import {BEAT_DEFS} from '../lib/timing';
import {BeatShell} from '../components/Ui';
import {Cloud, Ground, Hills, Palm, Sky, Ziggurat} from '../components/Scenery';
import {Stickman} from '../components/Stickman';
import {lerp, tween} from '../lib/anim';
import {BeatProps} from './types';

const HZ = 860;
const CX = 740;
const BASE = 940;
const W = 500;
const LEVELS = 5;
const TIER = 120;

/** Beat 7: ziggurat dibangun tingkat demi tingkat dengan pekerja kecil di tiap tingkat. */
export const Beat7: React.FC<BeatProps> = ({f, at}) => {
  const def = BEAT_DEFS[6];
  const buildAt = at(61); // "membangun"
  const doneAt = at(65); // "megah"
  const p = tween(f, Math.max(6, buildAt - 8), Math.max(30, doneAt - buildAt + 16), 0, LEVELS, (t) => t);
  const camY = tween(f, 0, 90, 70, 0);
  const builders = [0, 1, 2, 3].map((k) => {
    const wk = W * (1 - 0.5 * (k / LEVELS));
    const topY = BASE - (k + 1) * TIER;
    const x = CX - wk / 2 + 20 + k * 30;
    return {k, x, y: topY - 658 * 0.16};
  });
  return (
    <BeatShell f={f} title={def.title} label={def.label} labelAt={buildAt}>
      <Sky id="sky7" h={HZ} stops={['#7EC0D4', '#F7E3B5']} />
      <Cloud x={300 + f * 0.3} y={110} s={1.2} />
      <Cloud x={900 - f * 0.2} y={230} s={0.8} />
      <g transform={`translate(0 ${camY})`}>
        <Hills hz={HZ} amp={60} color="#D8B98A" seed={2} />
        <Ground hz={HZ} bottom={1050} vpx={CX} color="#E2B777" line={COLORS.mudDark} />
        <Ziggurat cx={CX} baseY={BASE} w={W} levels={LEVELS} tierH={TIER} p={p} />
        {/* perancah dan tangga kayu */}
        <g stroke="#6B3F1D" strokeWidth={8} strokeLinecap="round">
          <path d={`M1000 ${BASE} V${BASE - 3 * TIER}`} />
          <path d={`M1030 ${BASE} V${BASE - 3 * TIER}`} />
          {Array.from({length: 11}, (_, i) => (
            <path key={i} d={`M1000 ${BASE - 30 - i * 40} H1030`} strokeWidth={5} />
          ))}
        </g>
        {builders.map((b) =>
          p > b.k + 0.9 ? (
            <Stickman
              key={b.k}
              x={b.x}
              y={b.y}
              scale={0.16}
              front={{a: 100 + Math.sin(f * 0.3 + b.k) * 30, b: 20}}
              back={{a: 60, b: 20}}
              face="normal"
            />
          ) : null,
        )}
        <Palm x={1040} y={960} s={0.6} sway={Math.sin(f * 0.06) * 4} />
      </g>
      <ellipse cx={240} cy={1008} rx={130} ry={16} fill={COLORS.shadow} opacity={0.35} />
      <Stickman
        x={40}
        y={350}
        front={{a: lerp(40, 125, tween(f, 0, 24, 0, 1)), b: 0}}
        back={{a: 6, b: 8}}
        face="surprised"
        blink={false}
        sway={Math.sin(f * 0.15) * 8}
        bob={Math.sin(f * 0.12) * 3}
      />
    </BeatShell>
  );
};

import React from 'react';
import {COLORS} from '../config';
import {BEAT_DEFS} from '../lib/timing';
import {BeatShell} from '../components/Ui';
import {Cloud, Ground, Hills, House, Palm, River, Sky, Wheat} from '../components/Scenery';
import {Stickman} from '../components/Stickman';
import {clamp01, lerp, tween} from '../lib/anim';
import {BeatProps} from './types';

const HZ = 420;
const VPX = 770;
const ROWS_LEFT = [-100, 100, 300, 470];
const ROWS_RIGHT = [1130, 1250];

/** Beat 6: parit air mengalir lewat ladang, gandum tumbuh berurutan sepanjang parit. */
export const Beat6: React.FC<BeatProps> = ({f, at}) => {
  const def = BEAT_DEFS[5];
  const growAt = at(53); // "irigasi"
  const swing = Math.sin(f * 0.22);
  const front = {a: 60 + swing * 18, b: 20};
  const hoe = 40 + swing * 28;
  const plants: React.ReactNode[] = [];
  let n = 0;
  [...ROWS_LEFT, ...ROWS_RIGHT].forEach((bx) => {
    for (let k = 0; k < 7; k++) {
      const d = 0.12 + (k / 7) * 0.86;
      const x = lerp(VPX, bx, d);
      const y = lerp(HZ, 1050, d);
      const grow = clamp01((f - growAt - n * 0.8) / 16);
      plants.push(<Wheat key={`${bx}-${k}`} x={x} y={y} s={0.25 + d * 0.9} grow={grow} />);
      n++;
    }
  });
  return (
    <BeatShell f={f} title={def.title} label={def.label} labelAt={growAt}>
      <Sky id="sky6" h={HZ} stops={['#8EC9D8', '#F8E8BC']} />
      <Cloud x={260 + f * 0.3} y={100} s={1.1} />
      <Hills hz={HZ} amp={50} color="#D8B98A" seed={5} />
      <House x={200} y={HZ + 6} w={50} h={44} d={18} />
      <House x={880} y={HZ + 6} w={60} h={52} d={20} side="left" />
      <Palm x={560} y={HZ + 10} s={0.5} sway={Math.sin(f * 0.07) * 3} />
      <Ground hz={HZ} bottom={1050} vpx={VPX} color="#D9B070" line={COLORS.mudDark} />
      <River vpx={VPX} hz={HZ} bottom={1050} xl={600} xr={1040} f={f} />
      {plants}
      <ellipse cx={240} cy={1008} rx={130} ry={16} fill={COLORS.shadow} opacity={0.35} />
      <Stickman
        x={40}
        y={350}
        front={front}
        back={{a: 40, b: 30}}
        tool={{kind: 'hoe', angle: hoe}}
        lean={6}
        face="happy"
        blink={f % 96 < 4}
        sway={Math.sin(f * 0.15) * 8}
        bob={Math.abs(swing) * 3}
      />
    </BeatShell>
  );
};

import React from 'react';
import {spring} from 'remotion';
import {COLORS, FONT, FPS} from '../config';
import {BEAT_DEFS} from '../lib/timing';
import {BeatShell} from '../components/Ui';
import {BrickWall, Glyph, Tablet} from '../components/Scenery';
import {Stickman} from '../components/Stickman';
import {tween} from '../lib/anim';
import {BeatProps} from './types';

const rad = (d: number) => (d * Math.PI) / 180;

/** Beat 4: angka "60" diukir di tablet, lalu lingkaran 60 titik berubah menjadi jam. */
export const Beat4: React.FC<BeatProps> = ({f, at}) => {
  const def = BEAT_DEFS[3];
  const rise = tween(f, 0, 20, 700, 0);
  const sixtyAt = at(33); // "60"
  const clockAt = at(40); // "waktu"
  const pop = spring({frame: f - sixtyAt, fps: FPS, config: {damping: 10, stiffness: 160}});
  const ticks = Math.floor(tween(f, sixtyAt + 6, Math.max(10, clockAt - sixtyAt - 6), 0, 60, (t) => t));
  const handsOn = f >= clockAt;
  const minute = (f - clockAt) * 4;
  const cx = 760;
  const cy = 760;
  return (
    <BeatShell f={f} title={def.title} label={def.label} labelAt={at(31)}>
      <BrickWall h={1050} />
      <rect x={0} y={970} width={1080} height={80} fill={COLORS.wood} />
      <path d="M0 970 H1080" stroke={COLORS.ink} strokeWidth={5} />
      <g transform={`translate(0 ${rise})`}>
        <Tablet x={500} y={110} w={520} h={400}>
          {[0, 1, 2].map((i) => (
            <Glyph key={i} x={560 + i * 90} y={150} s={0.9} k={i + 1} />
          ))}
          <text
            x={760}
            y={410}
            textAnchor="middle"
            fontFamily={FONT}
            fontSize={230}
            fill={COLORS.shadow}
            stroke={COLORS.ink}
            strokeWidth={4}
            transform={`translate(760 330) scale(${f < sixtyAt ? 0 : 0.4 + 0.6 * pop}) translate(-760 -330)`}
          >
            60
          </text>
        </Tablet>
        <circle cx={cx} cy={cy} r={170} fill="#F6EBD0" stroke={COLORS.ink} strokeWidth={8} />
        {Array.from({length: ticks}, (_, i) => {
          const a = rad(i * 6 - 90);
          const long = i % 5 === 0;
          const r1 = 150;
          const r2 = long ? 118 : 134;
          return (
            <path
              key={i}
              d={`M${cx + Math.cos(a) * r1} ${cy + Math.sin(a) * r1} L${cx + Math.cos(a) * r2} ${cy + Math.sin(a) * r2}`}
              stroke={COLORS.ink}
              strokeWidth={long ? 7 : 3}
              strokeLinecap="round"
            />
          );
        })}
        {handsOn ? (
          <g strokeLinecap="round" stroke={COLORS.ink}>
            <path d={`M${cx} ${cy} L${cx + Math.cos(rad(minute / 12 - 90)) * 80} ${cy + Math.sin(rad(minute / 12 - 90)) * 80}`} strokeWidth={12} />
            <path d={`M${cx} ${cy} L${cx + Math.cos(rad(minute - 90)) * 120} ${cy + Math.sin(rad(minute - 90)) * 120}`} strokeWidth={7} />
            <circle cx={cx} cy={cy} r={10} fill={COLORS.cape} />
          </g>
        ) : null}
      </g>
      <ellipse cx={240} cy={1008} rx={130} ry={16} fill={COLORS.shadow} opacity={0.35} />
      <Stickman
        x={40}
        y={350}
        front={{a: 100, b: 8}}
        back={{a: 6, b: 8}}
        tool={{kind: 'pointer', angle: 100}}
        face={handsOn ? 'surprised' : 'think'}
        blink={f % 96 < 4}
        sway={Math.sin(f * 0.15) * 8}
        bob={Math.sin(f * 0.12) * 3}
      />
    </BeatShell>
  );
};

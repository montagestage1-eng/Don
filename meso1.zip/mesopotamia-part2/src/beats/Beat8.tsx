import React from 'react';
import {BEAT_DEFS} from '../lib/timing';
import {BeatShell} from '../components/Ui';
import {Palm, Sky, Ziggurat} from '../components/Scenery';
import {Stickman} from '../components/Stickman';
import {easeIO, tween} from '../lib/anim';
import {BeatProps} from './types';

const HZ = 600;
const CX = 760;
const SIL = {front: '#6A3A22', side: '#4A2615', top: '#7C4A2C', stair: '#7C4A2C'};

/** Beat 8: matahari terbenam di balik ziggurat, kamera mundur pelan. */
export const Beat8: React.FC<BeatProps> = ({f, at}) => {
  const def = BEAT_DEFS[7];
  const zoom = tween(f, 0, 200, 1.15, 1, easeIO);
  const sunY = tween(f, 0, 200, 340, 480, easeIO);
  const strips = Array.from({length: 10}, (_, i) => {
    const y = HZ + 24 + i * 38;
    const wdt = 40 + i * 16 + Math.sin(f * 0.1 + i) * 8;
    const dx = Math.sin(i * 2.1 + f * 0.08) * 16;
    return <path key={i} d={`M${CX + dx - wdt / 2} ${y} H${CX + dx + wdt / 2}`} stroke="#FFD76A" strokeWidth={4} strokeLinecap="round" opacity={0.7} />;
  });
  return (
    <BeatShell f={f} title={def.title} label={def.label} labelAt={at(76)}>
      <g transform={`translate(${CX} ${HZ}) scale(${zoom}) translate(${-CX} ${-HZ})`}>
        <Sky id="sky8" h={HZ} stops={['#D8553B', '#FBE3A0', '#F2A65A']} />
        <circle cx={CX} cy={sunY} r={210} fill="#FFE9A8" />
        <circle cx={CX} cy={sunY} r={160} fill="#FFD76A" />
        <rect x={-300} y={HZ} width={1680} height={700} fill="#C9703A" />
        <Ziggurat cx={CX} baseY={HZ} w={380} levels={5} tierH={56} p={5} colors={SIL} stroke="#3A1E10" />
        {strips}
        <Palm x={1000} y={HZ + 20} s={0.7} sway={Math.sin(f * 0.06) * 4} color="#3A4A22" />
        <Palm x={940} y={HZ + 30} s={0.5} sway={Math.sin(f * 0.07 + 2) * 4} color="#3A4A22" />
      </g>
      <ellipse cx={240} cy={1008} rx={130} ry={16} fill="#3A1E10" opacity={0.4} />
      <Stickman
        x={40}
        y={350}
        front={{a: 8, b: 6}}
        back={{a: 6, b: 6}}
        face="happy"
        blink={f % 96 < 4}
        sway={Math.sin(f * 0.12) * 10}
        bob={Math.sin(f * 0.1) * 3}
      />
    </BeatShell>
  );
};

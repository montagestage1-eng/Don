import React from 'react';
import {random, spring} from 'remotion';
import {COLORS, FPS} from '../config';
import {BEAT_DEFS} from '../lib/timing';
import {BeatShell} from '../components/Ui';
import {House, Sky} from '../components/Scenery';
import {Stickman} from '../components/Stickman';
import {clamp01, tween} from '../lib/anim';
import {BeatProps} from './types';

const NIGHT_HOUSE = {front: '#14394A', side: '#0D2733', top: '#1C4B5E'};
const STARS = Array.from({length: 70}, (_, i) => ({
  x: random(`star-x-${i}`) * 1080,
  y: random(`star-y-${i}`) * 620,
  r: 1.4 + random(`star-r-${i}`) * 2,
  ph: random(`star-p-${i}`) * 6.28,
}));
const CONSTELLATION: [number, number][] = [
  [560, 210],
  [660, 290],
  [770, 240],
  [850, 340],
  [950, 300],
  [770, 400],
];

/** Beat 5: langit malam, rasi bintang tersambung, lalu 12 fase bulan membentuk kalender. */
export const Beat5: React.FC<BeatProps> = ({f, at}) => {
  const def = BEAT_DEFS[4];
  const starAt = at(44); // "mempelajari bintang"
  const calAt = at(47); // "planet, ... kalender"
  const draw = tween(f, starAt, 40, 0, CONSTELLATION.length - 1, (t) => t);
  const tilt = tween(f, 0, 30, 8, 0);
  const ex = 520;
  const ey = 820;
  const ox = 980;
  const oy = 430;
  const mx = ex + (ox - ex) * 0.4;
  const my = ey + (oy - ey) * 0.4;
  return (
    <BeatShell f={f} title={def.title} label={def.label} labelAt={calAt}>
      <Sky id="sky5" h={1050} stops={[COLORS.nightSky, '#1E4F5E']} />
      {STARS.map((s, i) => (
        <circle key={i} cx={s.x} cy={s.y} r={s.r * (0.8 + 0.3 * Math.sin(f * 0.1 + s.ph))} fill="#FFF3D6" />
      ))}
      {/* rasi bintang */}
      {CONSTELLATION.slice(0, -1).map((p, i) => {
        const t = clamp01(draw - i);
        const q = CONSTELLATION[i + 1];
        return t > 0 ? (
          <path key={i} d={`M${p[0]} ${p[1]} L${p[0] + (q[0] - p[0]) * t} ${p[1] + (q[1] - p[1]) * t}`} stroke={COLORS.gold} strokeWidth={4} strokeLinecap="round" />
        ) : null;
      })}
      {CONSTELLATION.map((p, i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r={i <= draw + 0.01 ? 11 : 6} fill={i <= draw + 0.01 ? COLORS.gold : '#FFF3D6'} />
      ))}
      {/* kalender: 12 fase bulan */}
      {f >= calAt ? (
        <g>
          <path d="M500 112 H1020" stroke={COLORS.gold} strokeWidth={4} />
          {Array.from({length: 12}, (_, i) => {
            const pop = spring({frame: f - calAt - i * 2, fps: FPS, config: {damping: 12, stiffness: 200}});
            const cx = 530 + i * 44;
            const shift = ((i / 11) * 2 - 1) * 20;
            return (
              <g key={i} transform={`translate(${cx} 80) scale(${pop})`}>
                <circle cx={0} cy={0} r={18} fill="#FFF3D6" />
                <circle cx={shift} cy={0} r={18} fill={COLORS.nightSky} />
                <circle cx={0} cy={0} r={18} fill="none" stroke="#FFF3D6" strokeWidth={2} />
              </g>
            );
          })}
        </g>
      ) : null}
      {/* siluet kota */}
      <rect x={0} y={985} width={1080} height={80} fill="#10303A" />
      <House x={500} y={986} w={80} h={60} d={26} colors={NIGHT_HOUSE} detail={false} />
      <House x={960} y={986} w={70} h={80} d={24} colors={NIGHT_HOUSE} detail={false} />
      {/* teropong di atas tripod */}
      <g stroke={COLORS.ink} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round">
        <path d={`M${mx} ${my} L600 1000`} stroke="#6B4A2A" strokeWidth={14} />
        <path d={`M${mx} ${my} L710 1000`} stroke="#6B4A2A" strokeWidth={14} />
        <path d={`M${mx} ${my} L820 985`} stroke="#6B4A2A" strokeWidth={14} />
        <g transform={`rotate(${-tilt} ${mx} ${my})`}>
          <path d={`M${ex} ${ey} L${ox} ${oy}`} stroke={COLORS.ink} strokeWidth={64} />
          <path d={`M${ex} ${ey} L${ox} ${oy}`} stroke="#B8832C" strokeWidth={54} />
          <path d={`M${ex + 80} ${ey - 73} L${ex + 110} ${ey - 100}`} stroke={COLORS.gold} strokeWidth={60} />
          <circle cx={ex} cy={ey} r={20} fill="#6B4A2A" />
          <ellipse cx={ox} cy={oy} rx={22} ry={36} transform={`rotate(42 ${ox} ${oy})`} fill="#9CD3E0" />
        </g>
      </g>
      <ellipse cx={240} cy={1008} rx={130} ry={16} fill="#000000" opacity={0.3} />
      <Stickman
        x={40}
        y={350}
        front={{a: 135, b: 0}}
        back={{a: 6, b: 8}}
        face="surprised"
        blink={false}
        sway={Math.sin(f * 0.15) * 8}
        bob={Math.sin(f * 0.12) * 3}
      />
    </BeatShell>
  );
};

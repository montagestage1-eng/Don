import React from 'react';
import {AbsoluteFill, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Audio} from '@remotion/media';
import {TRANSITION_FRAMES} from './config';
import {BEATS, WORDS} from './lib/timing';
import {Reveal, RevealKind, SubtitleLayer} from './components/Ui';
import {BeatProps} from './beats/types';
import {Beat1} from './beats/Beat1';
import {Beat2} from './beats/Beat2';
import {Beat3} from './beats/Beat3';
import {Beat4} from './beats/Beat4';
import {Beat5} from './beats/Beat5';
import {Beat6} from './beats/Beat6';
import {Beat7} from './beats/Beat7';
import {Beat8} from './beats/Beat8';
import {BEAT_DEFS} from './lib/timing';

const BEAT_COMPONENTS: React.FC<BeatProps>[] = [Beat1, Beat2, Beat3, Beat4, Beat5, Beat6, Beat7, Beat8];

/** Transisi masuk tiap beat: wipe tanah liat, whip-pan, roda menggelinding, iris, matahari terbit, banjir, turun. */
const REVEALS: RevealKind[] = ['none', 'wipeLeft', 'whip', 'wheel', 'iris', 'sunrise', 'flood', 'drop'];

const BeatFrame: React.FC<{index: number}> = ({index}) => {
  const frame = useCurrentFrame();
  const lead = index === 0 ? 0 : TRANSITION_FRAMES;
  const f = frame - lead;
  const beatStart = BEATS[index].start;
  const at = (w: number) => WORDS[w].startFrame - beatStart;
  const Comp = BEAT_COMPONENTS[index];
  return (
    <Reveal kind={REVEALS[index]} frame={frame}>
      <Comp f={f} at={at} />
    </Reveal>
  );
};

export const Mesopotamia: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#2B1A0E'}}>
      <Audio src={staticFile('narasi.mp3')} />
      {BEATS.map((b, i) => {
        // beat berikutnya mulai TRANSITION_FRAMES lebih awal supaya transisinya selesai tepat di batas beat
        const from = i === 0 ? 0 : b.start - TRANSITION_FRAMES;
        const end = i + 1 < BEATS.length ? BEATS[i + 1].start : b.end;
        return (
          <Sequence key={BEAT_DEFS[i].title} from={from} durationInFrames={Math.max(1, end - from)}>
            <BeatFrame index={i} />
          </Sequence>
        );
      })}
      <SubtitleLayer />
    </AbsoluteFill>
  );
};

import React from 'react';
import {COLORS} from '../config';

/** Sudut dalam derajat dari posisi "lurus ke bawah"; positif = ke arah kanan (arah hadap). */
export type Arm = {a: number; b: number};
export type Face = 'normal' | 'happy' | 'think' | 'surprised';
export type Tool = {kind: 'pointer' | 'hoe'; angle: number};

type Props = {
  x: number;
  y: number;
  scale?: number;
  front: Arm;
  back: Arm;
  /** fase langkah (radian). Kosongkan untuk berdiri. */
  walk?: number;
  lean?: number;
  face?: Face;
  blink?: boolean;
  sway?: number;
  tool?: Tool;
  bob?: number;
};

const rad = (d: number) => (d * Math.PI) / 180;
const pt = (x: number, y: number, ang: number, len: number): [number, number] => [
  x + len * Math.sin(rad(ang)),
  y + len * Math.cos(rad(ang)),
];

const SX = 200;
const SY = 205;
const HX = 200;
const HY = 400;
const ARM = 85;
const LEG = 120;

const armPoints = (sx: number, sy: number, arm: Arm) => {
  const e = pt(sx, sy, arm.a, ARM);
  const h = pt(e[0], e[1], arm.a + arm.b, ARM);
  return {e, h};
};

const legPoints = (angle: number, bend: number) => {
  const k = pt(HX, HY, angle, LEG);
  const a = pt(k[0], k[1], angle - bend, LEG);
  return {k, a};
};

const Eyes: React.FC<{face: Face; blink: boolean}> = ({face, blink}) => {
  const s = {stroke: COLORS.ink, strokeWidth: 7, strokeLinecap: 'round' as const, fill: 'none'};
  if (face === 'happy') {
    return (
      <g {...s}>
        <path d="M160 112 Q175 88 190 112" />
        <path d="M210 112 Q225 88 240 112" />
        <path d="M170 142 Q200 172 230 142" />
      </g>
    );
  }
  if (face === 'surprised') {
    return (
      <g>
        <ellipse cx={175} cy={104} rx={9} ry={19} fill={COLORS.ink} />
        <ellipse cx={225} cy={104} rx={9} ry={19} fill={COLORS.ink} />
        <ellipse cx={200} cy={152} rx={13} ry={17} fill={COLORS.ink} />
      </g>
    );
  }
  if (blink) {
    return (
      <g {...s}>
        <path d="M165 108 L185 108" />
        <path d="M215 108 L235 108" />
      </g>
    );
  }
  return (
    <g {...s}>
      <path d="M175 88 L175 124" />
      <path d="M225 88 L225 124" />
      {face === 'think' ? (
        <>
          <path d="M208 68 L246 78" />
          <path d="M184 148 L216 142" />
        </>
      ) : null}
    </g>
  );
};

export const Stickman: React.FC<Props> = ({
  x,
  y,
  scale = 1,
  front,
  back,
  walk,
  lean = 0,
  face = 'normal',
  blink = false,
  sway = 0,
  tool,
  bob = 0,
}) => {
  const fa = armPoints(SX + 8, SY, front);
  const ba = armPoints(SX - 8, SY, back);
  const w = walk ?? 0;
  const walking = walk !== undefined;
  const A1 = walking ? 28 * Math.sin(w) : 6;
  const A2 = walking ? -28 * Math.sin(w) : -6;
  const B1 = walking ? 30 * Math.max(0, Math.cos(w)) : 0;
  const B2 = walking ? 30 * Math.max(0, -Math.cos(w)) : 0;
  const L1 = legPoints(A1, B1);
  const L2 = legPoints(A2, B2);
  const capeBack = `M175 200 C130 230 ${90 + sway} 330 ${50 + sway * 1.5} 480 L${120 + sway} 470 L190 440 L225 410 L225 205 Z`;

  const Leg: React.FC<{l: ReturnType<typeof legPoints>}> = ({l}) => (
    <g>
      <path
        d={`M${HX} ${HY} L${l.k[0]} ${l.k[1]} L${l.a[0]} ${l.a[1]}`}
        stroke={COLORS.ink}
        strokeWidth={11}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <ellipse cx={l.a[0] + 16} cy={l.a[1] + 6} rx={28} ry={13} fill="#6B3F1D" stroke={COLORS.ink} strokeWidth={4} />
    </g>
  );

  const Arm2: React.FC<{p: ReturnType<typeof armPoints>; sx: number}> = ({p, sx}) => (
    <g>
      <path
        d={`M${sx} ${SY} L${p.e[0]} ${p.e[1]} L${p.h[0]} ${p.h[1]}`}
        stroke={COLORS.ink}
        strokeWidth={10}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <circle cx={p.h[0]} cy={p.h[1]} r={10} fill={COLORS.ink} />
    </g>
  );

  let toolEl: React.ReactNode = null;
  if (tool) {
    const [hx, hy] = fa.h;
    if (tool.kind === 'pointer') {
      const e = pt(hx, hy, tool.angle, 130);
      toolEl = (
        <g>
          <path d={`M${hx} ${hy} L${e[0]} ${e[1]}`} stroke="#6B3F1D" strokeWidth={7} strokeLinecap="round" />
          <circle cx={e[0]} cy={e[1]} r={7} fill={COLORS.gold} stroke={COLORS.ink} strokeWidth={3} />
        </g>
      );
    } else {
      const e = pt(hx, hy, tool.angle, 200);
      const b1 = pt(e[0], e[1], tool.angle + 90, 55);
      const b2 = pt(b1[0], b1[1], tool.angle, 30);
      const b3 = pt(e[0], e[1], tool.angle, 30);
      toolEl = (
        <g>
          <path d={`M${hx} ${hy} L${e[0]} ${e[1]}`} stroke="#6B3F1D" strokeWidth={9} strokeLinecap="round" />
          <polygon
            points={`${e[0]},${e[1]} ${b1[0]},${b1[1]} ${b2[0]},${b2[1]} ${b3[0]},${b3[1]}`}
            fill="#7C7C74"
            stroke={COLORS.ink}
            strokeWidth={4}
          />
        </g>
      );
    }
  }

  return (
    <g transform={`translate(${x} ${y + bob}) scale(${scale})`}>
      <Leg l={L2} />
      <Leg l={L1} />
      <g transform={`rotate(${lean} ${HX} ${HY})`}>
        <path d={capeBack} fill={COLORS.cape} stroke={COLORS.ink} strokeWidth={4} strokeLinejoin="round" />
        <path
          d={`M${50 + sway * 1.5} 480 L${120 + sway} 470 L190 440`}
          stroke={COLORS.gold}
          strokeWidth={7}
          fill="none"
          strokeLinecap="round"
        />
        <Arm2 p={ba} sx={SX - 8} />
        <path d={`M${SX} 188 L${SX} ${HY}`} stroke={COLORS.ink} strokeWidth={11} strokeLinecap="round" />
        <polygon
          points="168,205 232,205 244,410 156,410"
          fill={COLORS.tunic}
          stroke={COLORS.ink}
          strokeWidth={4}
          strokeLinejoin="round"
        />
        <rect x={158} y={330} width={84} height={16} fill="#6B3F1D" />
        <path d="M150 200 Q200 245 250 200 L240 183 Q200 214 160 183 Z" fill={COLORS.cape} stroke={COLORS.ink} strokeWidth={4} />
        <circle cx={200} cy={100} r={88} fill="#FFFFFF" stroke={COLORS.ink} strokeWidth={6} />
        <Eyes face={face} blink={blink} />
        <Arm2 p={fa} sx={SX + 8} />
        {toolEl}
      </g>
    </g>
  );
};

import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame} from 'remotion';
import {COLORS, FONT, FPS, HEIGHT, LAYOUT, TRANSITION_FRAMES, WIDTH} from '../config';
import {easeIO, tween} from '../lib/anim';
import {PAGES} from '../lib/pages';
import {WORDS} from '../lib/timing';
import {Wheel} from './Scenery';

/* ---------- Kerangka satu beat: judul, label info, arena ---------- */

type ShellProps = {
  f: number;
  title: string;
  label: string;
  labelAt: number;
  children: React.ReactNode;
};

const TITLE_PATH =
  'M48 0 H912 V24 H936 V48 H960 V122 H936 V146 H912 V170 H48 V146 H24 V122 H0 V48 H24 V24 H48 Z';

const zigzag = (() => {
  let d = 'M0 30';
  for (let x = 0; x < WIDTH; x += 24) d += ` L${x + 12} 6 L${x + 24} 30`;
  return d;
})();

export const BeatShell: React.FC<ShellProps> = ({f, title, label, labelAt, children}) => {
  const {title: T, label: L, arena: A, decor: D} = LAYOUT;
  const ty = tween(f, 0, 16, -36, 0);
  const lp = spring({frame: f - labelAt, fps: FPS, config: {damping: 12, stiffness: 180}});
  const lScale = 1.2 - 0.2 * lp;
  const lRot = -2 * (1 - lp);
  const lw = Math.min(L.w, 70 + label.length * 24);
  const titleSize = Math.min(84, Math.floor(880 / (title.length * 0.66)));
  return (
    <AbsoluteFill style={{backgroundColor: COLORS.night}}>
      <svg
        style={{position: 'absolute', left: T.x, top: T.y, width: T.w, height: T.h, transform: `translateY(${ty}px)`}}
        viewBox={`0 0 ${T.w} ${T.h}`}
      >
        <path d={TITLE_PATH} fill={COLORS.clay} stroke={COLORS.ink} strokeWidth={6} strokeLinejoin="round" />
        <path d="M60 16 H900 V154 H60 Z" fill="none" stroke={COLORS.mudDark} strokeWidth={3} />
        <text x={T.w / 2} y={52} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={28} letterSpacing={6} fill={COLORS.capeDark}>
          MESOPOTAMIA · PART 2
        </text>
        <text x={T.w / 2} y={128} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={titleSize} fill={COLORS.ink}>
          {title}
        </text>
      </svg>

      <svg
        style={{
          position: 'absolute',
          left: L.x,
          top: L.y,
          width: L.w,
          height: L.h,
          overflow: 'visible',
          visibility: f < labelAt ? 'hidden' : 'visible',
          transformOrigin: '0px 40px',
          transform: `scale(${lScale}) rotate(${lRot}deg)`,
        }}
        viewBox={`0 0 ${L.w} ${L.h}`}
      >
        <polygon points={`0,0 ${lw},0 ${lw - 26},${L.h / 2} ${lw},${L.h} 0,${L.h}`} fill={COLORS.gold} stroke={COLORS.ink} strokeWidth={5} strokeLinejoin="round" />
        <text x={26} y={55} fontFamily={FONT} fontWeight={900} fontSize={38} fill={COLORS.ink}>
          {label}
        </text>
      </svg>

      <div style={{position: 'absolute', left: A.x, top: A.y, width: A.w, height: A.h, overflow: 'hidden'}}>
        <svg width={A.w} height={A.h} viewBox={`0 0 ${A.w} ${A.h}`} style={{display: 'block'}}>
          {children}
        </svg>
      </div>

      <svg style={{position: 'absolute', left: D.x, top: D.y, width: D.w, height: D.h}} viewBox={`0 0 ${D.w} ${D.h}`}>
        <path d={zigzag} stroke={COLORS.clay} strokeWidth={6} fill="none" strokeLinejoin="round" />
      </svg>
    </AbsoluteFill>
  );
};

/* ---------- Transisi antar beat ---------- */

export type RevealKind = 'none' | 'wipeLeft' | 'whip' | 'wheel' | 'iris' | 'sunrise' | 'flood' | 'drop';

export const Reveal: React.FC<{kind: RevealKind; frame: number; children: React.ReactNode}> = ({kind, frame, children}) => {
  const p = kind === 'none' ? 1 : tween(frame, 0, TRANSITION_FRAMES, 0, 1, easeIO);
  const style: React.CSSProperties = {};
  let overlay: React.ReactNode = null;
  if (p < 1) {
    if (kind === 'wipeLeft') {
      const e = (1 - p) * WIDTH;
      style.clipPath = `inset(0px 0px 0px ${e}px)`;
      overlay = <div style={{position: 'absolute', left: e - 18, top: 0, width: 18, height: HEIGHT, backgroundColor: COLORS.shadow}} />;
    } else if (kind === 'whip') {
      style.transform = `translateX(${(1 - p) * WIDTH}px)`;
      style.filter = `blur(${(1 - p) * 18}px)`;
    } else if (kind === 'wheel') {
      const e = p * WIDTH;
      style.clipPath = `inset(0px ${WIDTH - e}px 0px 0px)`;
      overlay = (
        <svg style={{position: 'absolute', left: e - 170, top: 790, width: 340, height: 340}} viewBox="0 0 340 340">
          <Wheel cx={170} cy={170} r={150} rot={p * 900} />
        </svg>
      );
    } else if (kind === 'iris') {
      style.clipPath = `circle(${p * 1400}px at 540px 875px)`;
    } else if (kind === 'sunrise') {
      const e = (1 - p) * HEIGHT;
      style.clipPath = `inset(${e}px 0px 0px 0px)`;
      overlay = <div style={{position: 'absolute', left: 0, top: e - 12, width: WIDTH, height: 14, backgroundColor: COLORS.gold}} />;
    } else if (kind === 'flood') {
      const e = (1 - p) * (WIDTH + 120);
      const pts: string[] = [];
      for (let y = 0; y <= HEIGHT; y += 120) pts.push(`${e + 36 * Math.sin(y / 110 + p * 9)}px ${y}px`);
      style.clipPath = `polygon(${pts.join(',')},${WIDTH + 200}px ${HEIGHT}px,${WIDTH + 200}px 0px)`;
    } else if (kind === 'drop') {
      const e = (1 - p) * HEIGHT;
      style.clipPath = `inset(0px 0px ${e}px 0px)`;
      overlay = <div style={{position: 'absolute', left: 0, top: p * HEIGHT - 2, width: WIDTH, height: 14, backgroundColor: COLORS.gold}} />;
    }
  }
  return (
    <AbsoluteFill>
      <AbsoluteFill style={style}>{children}</AbsoluteFill>
      {overlay}
    </AbsoluteFill>
  );
};

/* ---------- Subtitle per kata dengan kotak kuning ---------- */

const SUB_FONT = 62;
const LINE_H = 88;

export const SubtitleLayer: React.FC = () => {
  const frame = useCurrentFrame();
  const {subtitle: S} = LAYOUT;
  let page = -1;
  for (let i = 0; i < PAGES.length; i++) if (PAGES[i].startFrame <= frame) page = i;
  if (page < 0) return null;
  const pg = PAGES[page];
  const pop = spring({frame: frame - pg.startFrame, fps: FPS, config: {damping: 16, stiffness: 220}});
  const rise = (1 - pop) * 18;
  const flat = pg.lines.flat();
  let active = flat[0];
  for (const i of flat) if (WORDS[i].startFrame <= frame) active = i;
  return (
    <div style={{position: 'absolute', left: S.x, top: S.y, width: S.w, height: S.h, transform: `translateY(${rise}px)`}}>
      {pg.lines.map((line, r) => (
        <div
          key={r}
          style={{
            position: 'absolute',
            left: 0,
            top: 8 + r * LINE_H,
            width: S.w,
            height: LINE_H,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 6,
            whiteSpace: 'nowrap',
          }}
        >
          {line.map((wi) => {
            const on = wi === active;
            return (
              <span
                key={wi}
                style={{
                  display: 'inline-block',
                  padding: '2px 12px',
                  fontFamily: FONT,
                  fontWeight: 900,
                  fontSize: SUB_FONT,
                  lineHeight: `${LINE_H - 14}px`,
                  backgroundColor: on ? COLORS.highlight : 'transparent',
                  color: on ? COLORS.ink : '#FFFFFF',
                  WebkitTextStroke: on ? '0px transparent' : `10px ${COLORS.ink}`,
                  paintOrder: 'stroke fill',
                }}
              >
                {WORDS[wi].text}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

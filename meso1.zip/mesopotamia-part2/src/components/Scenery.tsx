import React from 'react';
import {COLORS} from '../config';
import {clamp01, lerp} from '../lib/anim';

const rad = (d: number) => (d * Math.PI) / 180;

export const Sky: React.FC<{id: string; h: number; stops: [string, string, string?]}> = ({id, h, stops}) => (
  <g>
    <defs>
      <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={stops[0]} />
        {stops[2] ? <stop offset="0.55" stopColor={stops[2]} /> : null}
        <stop offset="1" stopColor={stops[1]} />
      </linearGradient>
    </defs>
    <rect x={-300} y={-300} width={1680} height={h + 300} fill={`url(#${id})`} />
  </g>
);

export const Cloud: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = '#FFF3D6'}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill={color}>
    <ellipse cx={0} cy={0} rx={74} ry={22} />
    <ellipse cx={-34} cy={-14} rx={34} ry={22} />
    <ellipse cx={20} cy={-24} rx={42} ry={27} />
  </g>
);

export const Hills: React.FC<{hz: number; amp: number; color: string; seed?: number}> = ({hz, amp, color, seed = 0}) => {
  let d = `M-200 ${hz}`;
  for (let i = -1; i <= 10; i++) {
    const px = i * 130;
    const py = hz - amp * (0.45 + 0.55 * Math.sin(i * 1.3 + seed) ** 2);
    d += ` L${px} ${py}`;
  }
  d += ` L1400 ${hz} Z`;
  return <path d={d} fill={color} />;
};

type HouseColors = {front: string; side: string; top: string};
const DAY: HouseColors = {front: COLORS.mud, side: COLORS.mudDark, top: COLORS.mudLight};

/** Kotak perspektif miring: (x, y) = pojok kiri-bawah muka depan. */
export const House: React.FC<{
  x: number;
  y: number;
  w: number;
  h: number;
  d: number;
  side?: 'left' | 'right';
  colors?: HouseColors;
  detail?: boolean;
}> = ({x, y, w, h, d, side = 'right', colors = DAY, detail = true}) => {
  const top = y - h;
  const sidePts =
    side === 'right'
      ? `${x + w},${top} ${x + w + d},${top - d / 2} ${x + w + d},${y - d / 2} ${x + w},${y}`
      : `${x},${top} ${x - d},${top - d / 2} ${x - d},${y - d / 2} ${x},${y}`;
  const topPts =
    side === 'right'
      ? `${x},${top} ${x + d},${top - d / 2} ${x + w + d},${top - d / 2} ${x + w},${top}`
      : `${x},${top} ${x - d},${top - d / 2} ${x + w - d},${top - d / 2} ${x + w},${top}`;
  return (
    <g stroke={COLORS.ink} strokeWidth={Math.max(2, w / 28)} strokeLinejoin="round">
      <polygon points={sidePts} fill={colors.side} />
      <polygon points={topPts} fill={colors.top} />
      <rect x={x} y={top} width={w} height={h} fill={colors.front} />
      {detail ? (
        <g fill={COLORS.ink} stroke="none">
          <path d={`M${x + w * 0.38} ${y} V${y - h * 0.4} Q${x + w * 0.5} ${y - h * 0.55} ${x + w * 0.62} ${y - h * 0.4} V${y} Z`} />
          <rect x={x + w * 0.1} y={top + h * 0.18} width={w * 0.14} height={h * 0.16} />
          <rect x={x + w * 0.76} y={top + h * 0.18} width={w * 0.14} height={h * 0.16} />
        </g>
      ) : null}
    </g>
  );
};

export const Palm: React.FC<{x: number; y: number; s?: number; sway?: number; color?: string}> = ({
  x,
  y,
  s = 1,
  sway = 0,
  color = COLORS.palm,
}) => {
  const tx = x + sway;
  const ty = y - 170 * s;
  const fronds = [-170, -135, -100, -60, -25, 10];
  return (
    <g>
      <path d={`M${x} ${y} Q${x + 16 * s + sway * 0.4} ${y - 90 * s} ${tx} ${ty}`} stroke="#6B4A2A" strokeWidth={13 * s} fill="none" strokeLinecap="round" />
      {fronds.map((a, i) => {
        const c = Math.cos(rad(a));
        const sn = Math.sin(rad(a));
        const ex = tx + c * 95 * s;
        const ey = ty + sn * 60 * s + 38 * s;
        const cx = tx + c * 50 * s;
        const cy = ty + sn * 50 * s - 24 * s;
        return <path key={i} d={`M${tx} ${ty} Q${cx} ${cy} ${ex} ${ey}`} stroke={color} strokeWidth={10 * s} fill="none" strokeLinecap="round" />;
      })}
    </g>
  );
};

export const Ground: React.FC<{hz: number; bottom: number; vpx: number; color: string; line: string}> = ({
  hz,
  bottom,
  vpx,
  color,
  line,
}) => (
  <g>
    <rect x={-400} y={hz} width={1880} height={bottom - hz + 400} fill={color} />
    {[-1000, -700, -450, -250, -80, 120, 320, 540, 760, 980, 1200, 1500, 1800, 2100].map((bx) => (
      <path key={bx} d={`M${vpx} ${hz} L${bx} ${bottom + 200}`} stroke={line} strokeWidth={3} opacity={0.35} />
    ))}
  </g>
);

export const River: React.FC<{vpx: number; hz: number; bottom: number; xl: number; xr: number; f: number}> = ({
  vpx,
  hz,
  bottom,
  xl,
  xr,
  f,
}) => {
  const waves = Array.from({length: 14}, (_, k) => {
    const u = (((f * 0.012 + k / 14) % 1) + 1) % 1;
    const d = Math.pow(u, 1.8);
    const y = lerp(hz, bottom, d);
    const l = lerp(vpx - 5, xl, d);
    const r = lerp(vpx + 5, xr, d);
    const x0 = l + (r - l) * ((k * 0.37) % 0.7);
    return <path key={k} d={`M${x0} ${y} H${x0 + (r - l) * 0.2}`} stroke={COLORS.riverLight} strokeWidth={2 + 5 * d} strokeLinecap="round" opacity={0.85} />;
  });
  return (
    <g>
      <polygon points={`${vpx - 5},${hz} ${vpx + 5},${hz} ${xr},${bottom} ${xl},${bottom}`} fill={COLORS.river} stroke="#8E5B2B" strokeWidth={7} strokeLinejoin="round" />
      {waves}
    </g>
  );
};

export const Boat: React.FC<{x: number; y: number; s: number}> = ({x, y, s}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} stroke={COLORS.ink} strokeWidth={4} strokeLinejoin="round">
    <path d="M-62 0 L62 0 L44 26 L-44 26 Z" fill="#7A4A24" />
    <path d="M0 0 V-120" strokeLinecap="round" />
    <path d="M4 -116 L4 -20 L66 -20 Z" fill="#F3E4C0" />
  </g>
);

type ZigColors = {front: string; side: string; top: string; stair: string};
const ZIG_DAY: ZigColors = {front: COLORS.mud, side: COLORS.mudDark, top: COLORS.mudLight, stair: COLORS.mudLight};

/** Ziggurat bertingkat. p = jumlah tingkat yang sudah terbangun (boleh pecahan). */
export const Ziggurat: React.FC<{
  cx: number;
  baseY: number;
  w: number;
  levels: number;
  tierH: number;
  p: number;
  colors?: ZigColors;
  temple?: boolean;
  stroke?: string;
}> = ({cx, baseY, w, levels, tierH, p, colors = ZIG_DAY, temple = true, stroke = COLORS.ink}) => {
  const tiers: React.ReactNode[] = [];
  for (let k = 0; k < levels; k++) {
    const vis = clamp01(p - k);
    if (vis <= 0) break;
    const wk = w * (1 - 0.5 * (k / levels));
    const d = 70 * (1 - 0.12 * k);
    const yB = baseY - k * tierH;
    const ht = tierH * vis;
    const x0 = cx - wk / 2;
    tiers.push(
      <g key={k} stroke={stroke} strokeWidth={3} strokeLinejoin="round">
        <polygon points={`${x0 + wk},${yB - ht} ${x0 + wk + d},${yB - ht - d / 2} ${x0 + wk + d},${yB - d / 2} ${x0 + wk},${yB}`} fill={colors.side} />
        <polygon points={`${x0},${yB - ht} ${x0 + d},${yB - ht - d / 2} ${x0 + wk + d},${yB - ht - d / 2} ${x0 + wk},${yB - ht}`} fill={colors.top} />
        <rect x={x0} y={yB - ht} width={wk} height={ht} fill={colors.front} />
      </g>,
    );
  }
  const built = Math.min(p, levels);
  const stairTop = baseY - built * tierH;
  const steps: React.ReactNode[] = [];
  for (let y = baseY - 22; y > stairTop; y -= 22) {
    const t = (baseY - y) / (levels * tierH);
    const half = lerp(46, 22, t);
    steps.push(<path key={y} d={`M${cx - half} ${y} H${cx + half}`} stroke={stroke} strokeWidth={2} opacity={0.6} />);
  }
  const topY = baseY - levels * tierH;
  const showTemple = temple && p >= levels - 0.05;
  const tw = w * 0.22;
  return (
    <g>
      {tiers}
      {built > 0 ? (
        <g>
          <polygon
            points={`${cx - 46},${baseY} ${cx + 46},${baseY} ${cx + lerp(46, 22, built / levels)},${stairTop} ${cx - lerp(46, 22, built / levels)},${stairTop}`}
            fill={colors.stair}
            stroke={stroke}
            strokeWidth={3}
          />
          {steps}
        </g>
      ) : null}
      {showTemple ? (
        <g stroke={stroke} strokeWidth={3} strokeLinejoin="round">
          <polygon points={`${cx + tw / 2},${topY} ${cx + tw / 2 + 26},${topY - 13} ${cx + tw / 2 + 26},${topY - 13 - tierH * 0.55} ${cx + tw / 2},${topY - tierH * 0.55}`} fill={colors.side} />
          <rect x={cx - tw / 2} y={topY - tierH * 0.55} width={tw} height={tierH * 0.55} fill={colors.front} />
          <rect x={cx - tw / 2 - 6} y={topY - tierH * 0.55 - 14} width={tw + 12} height={14} fill="#3E7F9A" />
        </g>
      ) : null}
    </g>
  );
};

export const Wheel: React.FC<{cx: number; cy: number; r: number; rot: number}> = ({cx, cy, r, rot}) => (
  <g transform={`rotate(${rot} ${cx} ${cy})`}>
    {Array.from({length: 8}, (_, k) => {
      const a = rad(k * 45);
      return <path key={k} d={`M${cx} ${cy} L${cx + Math.cos(a) * r} ${cy + Math.sin(a) * r}`} stroke="#A06A32" strokeWidth={r * 0.09} strokeLinecap="round" />;
    })}
    <circle cx={cx} cy={cy} r={r} fill="none" stroke="#6E4520" strokeWidth={r * 0.16} />
    <circle cx={cx} cy={cy} r={r * 0.2} fill="#3F2610" stroke={COLORS.ink} strokeWidth={4} />
  </g>
);

/** Papan tanah liat: (x, y, w, h) adalah muka depan; ketebalan tampak di kanan-bawah. */
export const Tablet: React.FC<{x: number; y: number; w: number; h: number; children?: React.ReactNode}> = ({x, y, w, h, children}) => {
  const shape = `${x + 12},${y} ${x + w - 12},${y + 5} ${x + w},${y + h - 12} ${x + w - 14},${y + h} ${x + 8},${y + h - 5} ${x},${y + 16}`;
  return (
    <g>
      <polygon points={shape} transform="translate(16 16)" fill={COLORS.shadow} stroke={COLORS.ink} strokeWidth={5} strokeLinejoin="round" />
      <polygon points={shape} fill={COLORS.mudLight} stroke={COLORS.ink} strokeWidth={5} strokeLinejoin="round" />
      {children}
    </g>
  );
};

const wedge = (x: number, y: number, ang: number, len: number) => {
  const r = rad(ang);
  const tx = x + Math.cos(r) * len;
  const ty = y + Math.sin(r) * len;
  const px = -Math.sin(r) * 6;
  const py = Math.cos(r) * 6;
  return `M${x} ${y} L${tx + px} ${ty + py} L${tx - px} ${ty - py} Z`;
};

const GLYPHS: number[][][] = [
  [[0, 0, 0, 30], [0, 18, 0, 30], [38, 6, 90, 26]],
  [[0, 0, 60, 32], [16, 0, 60, 32], [36, 4, 0, 24]],
  [[0, 10, 0, 40], [10, 0, 80, 30], [24, 0, 80, 30]],
  [[0, 0, 45, 30], [0, 26, 0, 34], [20, 8, 90, 22]],
  [[0, 0, 0, 22], [28, 0, 90, 30], [0, 30, 0, 22], [34, 8, 30, 20]],
];

export const Glyph: React.FC<{x: number; y: number; s: number; k: number}> = ({x, y, s, k}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill={COLORS.shadow}>
    {GLYPHS[k % GLYPHS.length].map((g, i) => (
      <path key={i} d={wedge(g[0], g[1], g[2], g[3])} />
    ))}
  </g>
);

/** Dinding bata lumpur untuk latar interior. */
export const BrickWall: React.FC<{h: number}> = ({h}) => {
  const rows: React.ReactNode[] = [];
  for (let r = 0; r * 70 < h; r++) {
    rows.push(<path key={`h${r}`} d={`M0 ${r * 70} H1080`} stroke={COLORS.shadow} strokeWidth={3} opacity={0.55} />);
    for (let c = 0; c < 9; c++) {
      const x = c * 140 + (r % 2 ? 70 : 0);
      rows.push(<path key={`v${r}-${c}`} d={`M${x} ${r * 70} V${r * 70 + 70}`} stroke={COLORS.shadow} strokeWidth={3} opacity={0.55} />);
    }
  }
  return (
    <g>
      <rect x={0} y={0} width={1080} height={h} fill={COLORS.mudDark} />
      {rows}
    </g>
  );
};

export const Wheat: React.FC<{x: number; y: number; s: number; grow: number}> = ({x, y, s, grow}) => {
  const hgt = 60 * s * grow;
  return (
    <g stroke="#7B9B3A" strokeWidth={Math.max(2, 4 * s)} strokeLinecap="round">
      {[-8, 0, 8].map((dx, i) => (
        <g key={i}>
          <path d={`M${x + dx * s} ${y} L${x + dx * s * 1.6} ${y - hgt}`} />
          <ellipse cx={x + dx * s * 1.6} cy={y - hgt - 6 * s * grow} rx={4 * s * grow} ry={10 * s * grow} fill={COLORS.gold} stroke="none" />
        </g>
      ))}
    </g>
  );
};

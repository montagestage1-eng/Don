# Mesopotamia Part 2: Penemuan yang Mengubah Dunia

Proyek Remotion (1080x1920, 30 fps).

- `public/narasi.mp3` : TIMPA dengan audio narasimu (file bawaan hanya placeholder senyap).
- `src/data/captions.ts` : timestamp SRT. Semua subtitle, sorotan kata, dan durasi beat dihitung dari sini.
- `src/config.ts` : `AUDIO_OFFSET` (geser sinkron, detik) dan tabel koordinat tata letak.
- `src/lib/timing.ts` : `BEAT_DEFS` (beat dimulai di kata ke-N).

Perintah: `npm install`, `npm run dev`, `npm run render`.
